package Registration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

import java.time.Duration;

public class testRegistration {
    WebDriver driver;
    WebDriverWait wait;
    @BeforeMethod
    public void setup() {
        // Initialize ChromeDriver
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        // Maximize browser window
        driver.manage().window().maximize();
    }

    @Test
    public void userRegistrationTest() throws InterruptedException {
        // Navigate to nopCommerce registration page
        driver.get("https://demo.nopcommerce.com/");
        //Chose register page
        driver.findElement(By.className("ico-register")).click();
        // Fill registration form
        driver.findElement(By.id("FirstName")).sendKeys("nada");
        driver.findElement(By.id("LastName")).sendKeys("hassan");
        driver.findElement(By.id("Email")).sendKeys("nadaa@example.com");
        driver.findElement(By.id("Password")).sendKeys("password");
        driver.findElement(By.id("ConfirmPassword")).sendKeys("password");
        Thread.sleep(2000);
        // Click on register button
        driver.findElement(By.id("register-button")).click();
        Thread.sleep(2000);


        // Wait for registration success message
        WebElement registrationSuccessMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("result")));

        // Verify registration success message
        assert registrationSuccessMessage.getText().equals("Your registration completed");

    }

    @AfterMethod
    public void Close() {
        // Close the browser
        driver.quit();
    }
}

